'use client'

import { useState, useEffect, createContext, useContext } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Bot, MessageSquare, Zap, Globe, Cloud, Code, ShoppingCart, Headphones, 
  Calendar, Newspaper, BarChart3, Check, Star, ArrowLeft, Moon, Sun, Play, 
  Send, Menu, X, Sparkles, Users, Shield, Rocket, Heart, Settings, Plus, 
  Trash2, Edit, Copy, RefreshCw, ChevronDown, LogOut, User, Bell, Search,
  ToggleLeft, ToggleRight, ExternalLink, Key, Radio
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Separator } from '@/components/ui/separator'
import { Switch } from '@/components/ui/switch'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { ScrollArea } from '@/components/ui/scroll-area'

// Types
interface User {
  id: string
  email: string
  name: string | null
  plan: string
  credits: number
}

interface Bot {
  id: string
  name: string
  token: string
  username: string | null
  description: string | null
  welcomeMessage: string | null
  isActive: boolean
  subscribersCount: number
  messagesCount: number
  createdAt: string
  commands?: BotCommand[]
  autoReplies?: AutoReply[]
  channels?: Channel[]
  _count?: {
    subscribers: number
    messages: number
    channels: number
  }
}

interface BotCommand {
  id: string
  command: string
  description: string | null
  response: string
  isActive: boolean
}

interface AutoReply {
  id: string
  keyword: string
  matchType: string
  response: string
  isActive: boolean
  priority: number
}

interface Channel {
  id: string
  channelId: string
  title: string
  username: string | null
  type: string
  isActive: boolean
}

interface Subscriber {
  id: string
  telegramId: string
  username: string | null
  firstName: string | null
  lastName: string | null
  isBlocked: boolean
  subscribedAt: string
  lastActiveAt: string | null
}

// Auth Context
const AuthContext = createContext<{
  user: User | null
  token: string | null
  login: (email: string, password: string) => Promise<void>
  register: (email: string, password: string, name?: string) => Promise<void>
  logout: () => void
  loading: boolean
}>({
  user: null,
  token: null,
  login: async () => {},
  register: async () => {},
  logout: () => {},
  loading: true,
})

// API Helper
async function api(endpoint: string, options: RequestInit = {}, token?: string) {
  const headers: HeadersInit = {
    'Content-Type': 'application/json',
    ...(token && { Authorization: `Bearer ${token}` }),
    ...options.headers,
  }

  const res = await fetch(`/api${endpoint}`, {
    ...options,
    headers,
  })

  const data = await res.json()
  
  if (!res.ok) {
    throw new Error(data.error || 'حدث خطأ')
  }

  return data
}

// Landing Page Component
function LandingPage({ onGetStarted }: { onGetStarted: () => void }) {
  const [darkMode, setDarkMode] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const features = [
    { icon: <Zap className="w-6 h-6" />, title: 'سحب وإفلات', description: 'أنشئ بوتك بسهولة دون خبرة برمجية' },
    { icon: <Bot className="w-6 h-6" />, title: 'قوالب جاهزة', description: 'اختر من بين قوالب جاهزة وخصصها' },
    { icon: <BarChart3 className="w-6 h-6" />, title: 'تحليلات متقدمة', description: 'تتبع أداء البوت والتفاعل' },
    { icon: <Globe className="w-6 h-6" />, title: 'دعم متعدد اللغات', description: 'دعم كامل للغة العربية' },
    { icon: <Cloud className="w-6 h-6" />, title: 'استضافة سحابية', description: 'استضافة آمنة بضمان 99.9%' },
    { icon: <Code className="w-6 h-6" />, title: 'API قوي', description: 'واجهة برمجية للتخصيص المتقدم' },
  ]

  const pricingPlans = [
    { name: 'مجاني', price: '0', features: ['بوت واحد', '500 رسالة/شهر', 'قوالب أساسية', 'دعم عبر البريد'], cta: 'ابدأ مجاناً' },
    { name: 'احترافي', price: '19', features: ['10 بوتات', '50,000 رسالة/شهر', 'جميع القوالب', 'دعم أولوية', 'API كامل'], highlighted: true, cta: 'ترقية الآن' },
    { name: 'مؤسسات', price: '49', features: ['بوتات غير محدودة', 'رسائل غير محدودة', 'دعم مخصص 24/7', 'سيرفر مخصص'], cta: 'تواصل معنا' },
  ]

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
    setMobileMenuOpen(false)
  }

  return (
    <div className={`min-h-screen bg-background transition-colors duration-300 ${darkMode ? 'dark' : ''}`}>
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-blue-500 flex items-center justify-center">
                <Bot className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold gradient-text">BotMaker</span>
            </div>

            <div className="hidden md:flex items-center gap-8">
              <button onClick={() => scrollToSection('features')} className="text-muted-foreground hover:text-foreground transition-colors">المميزات</button>
              <button onClick={() => scrollToSection('pricing')} className="text-muted-foreground hover:text-foreground transition-colors">الأسعار</button>
            </div>

            <div className="hidden md:flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => setDarkMode(!darkMode)}>
                {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </Button>
              <Button onClick={onGetStarted} className="bg-gradient-to-r from-violet-500 to-blue-500 hover:from-violet-600 hover:to-blue-600 text-white">
                ابدأ الآن مجاناً
              </Button>
            </div>

            <div className="md:hidden flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={() => setDarkMode(!darkMode)}>
                {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </Button>
              <Button variant="ghost" size="icon" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
            </div>
          </div>
        </div>

        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="md:hidden border-t bg-background">
              <div className="px-4 py-4 space-y-4">
                <button onClick={() => scrollToSection('features')} className="block w-full text-right text-muted-foreground">المميزات</button>
                <button onClick={() => scrollToSection('pricing')} className="block w-full text-right text-muted-foreground">الأسعار</button>
                <Button onClick={() => { onGetStarted(); setMobileMenuOpen(false) }} className="w-full bg-gradient-to-r from-violet-500 to-blue-500 text-white">
                  ابدأ الآن مجاناً
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-bl from-violet-500/10 via-transparent to-blue-500/10" />
        <div className="absolute top-20 right-1/4 w-96 h-96 bg-violet-500/20 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl" />
        
        <div className="max-w-7xl mx-auto relative text-center space-y-8">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            <Badge className="bg-violet-500/10 text-violet-600 dark:text-violet-400 border-violet-500/20 mb-4">
              <Sparkles className="w-3 h-3 ml-1" />
              أكثر من 10,000 بوت تم إنشاؤه
            </Badge>
          </motion.div>

          <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
            className="text-4xl md:text-6xl lg:text-7xl font-bold leading-tight">
            أنشئ <span className="gradient-text">بوت تليجرام</span><br />احترافي في دقائق
          </motion.h1>

          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
            className="text-xl text-muted-foreground max-w-2xl mx-auto">
            منصة متكاملة لإنشاء وإدارة بوتات تليجرام بدون برمجة. اربط البوت بقنواتك وتحكم به بالكامل.
          </motion.p>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" onClick={onGetStarted} className="bg-gradient-to-r from-violet-500 to-blue-500 text-white text-lg px-8 h-14 animate-pulse-glow">
              ابدأ الآن مجاناً <ArrowLeft className="w-5 h-5 mr-2" />
            </Button>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}
            className="flex items-center justify-center gap-8 pt-8">
            <div className="flex items-center gap-2"><Users className="w-5 h-5 text-violet-500" /><span className="text-muted-foreground">+10,000 مستخدم</span></div>
            <div className="flex items-center gap-2"><Bot className="w-5 h-5 text-blue-500" /><span className="text-muted-foreground">+15,000 بوت</span></div>
            <div className="flex items-center gap-2"><Shield className="w-5 h-5 text-emerald-500" /><span className="text-muted-foreground">آمن 100%</span></div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 bg-muted/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="bg-violet-500/10 text-violet-600 dark:text-violet-400 border-violet-500/20 mb-4">المميزات</Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">كل ما تحتاجه لإنشاء بوت <span className="gradient-text">احترافي</span></h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, idx) => (
              <Card key={idx} className="h-full card-hover border-transparent bg-background/60 backdrop-blur">
                <CardHeader>
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500/10 to-blue-500/10 flex items-center justify-center text-violet-500 mb-4">{feature.icon}</div>
                  <CardTitle>{feature.title}</CardTitle>
                </CardHeader>
                <CardContent><CardDescription>{feature.description}</CardDescription></CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="bg-violet-500/10 text-violet-600 dark:text-violet-400 border-violet-500/20 mb-4">الأسعار</Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">خطط <span className="gradient-text">مرنة</span> تناسب الجميع</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {pricingPlans.map((plan, idx) => (
              <Card key={idx} className={`h-full relative ${plan.highlighted ? 'border-2 border-violet-500 shadow-xl shadow-violet-500/10 scale-105' : ''}`}>
                {plan.highlighted && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <Badge className="bg-gradient-to-r from-violet-500 to-blue-500 text-white">الأكثر شعبية</Badge>
                  </div>
                )}
                <CardHeader className="text-center pb-2">
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <div className="mt-4"><span className="text-4xl font-bold">${plan.price}</span><span className="text-muted-foreground">/شهر</span></div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {plan.features.map((feature, fidx) => (
                    <div key={fidx} className="flex items-center gap-2"><Check className="w-5 h-5 text-emerald-500 flex-shrink-0" /><span className="text-sm">{feature}</span></div>
                  ))}
                </CardContent>
                <CardFooter>
                  <Button className={`w-full ${plan.highlighted ? 'bg-gradient-to-r from-violet-500 to-blue-500 text-white' : ''}`} variant={plan.highlighted ? 'default' : 'outline'} onClick={onGetStarted}>{plan.cta}</Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 border-t">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-sm text-muted-foreground">© 2024 BotMaker. جميع الحقوق محفوظة. صُنع بـ <Heart className="w-4 h-4 text-red-500 fill-red-500 inline" /></p>
        </div>
      </footer>
    </div>
  )
}

// Auth Form Component
function AuthForm({ onSuccess }: { onSuccess: () => void }) {
  const [isLogin, setIsLogin] = useState(true)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const { login, register } = useContext(AuthContext)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      if (isLogin) {
        await login(email, password)
      } else {
        await register(email, password, name)
      }
      onSuccess()
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-bl from-violet-500/10 via-background to-blue-500/10 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-500 to-blue-500 flex items-center justify-center mx-auto mb-4">
            <Bot className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl">{isLogin ? 'تسجيل الدخول' : 'إنشاء حساب جديد'}</CardTitle>
          <CardDescription>{isLogin ? 'أدخل بياناتك للدخول' : 'أنشئ حسابك مجاناً'}</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>}
            
            {!isLogin && (
              <div className="space-y-2">
                <Label htmlFor="name">الاسم</Label>
                <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="اسمك" />
              </div>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="email">البريد الإلكتروني</Label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="example@email.com" required />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">كلمة المرور</Label>
              <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" required />
            </div>
            
            <Button type="submit" className="w-full bg-gradient-to-r from-violet-500 to-blue-500 text-white" disabled={loading}>
              {loading ? 'جاري التحميل...' : (isLogin ? 'دخول' : 'إنشاء حساب')}
            </Button>
          </form>
          
          <div className="mt-4 text-center">
            <button onClick={() => setIsLogin(!isLogin)} className="text-sm text-violet-500 hover:underline">
              {isLogin ? 'ليس لديك حساب؟ سجل الآن' : 'لديك حساب؟ سجل دخول'}
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// Dashboard Component
function Dashboard() {
  const { user, token, logout } = useContext(AuthContext)
  const [bots, setBots] = useState<Bot[]>([])
  const [selectedBot, setSelectedBot] = useState<Bot | null>(null)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('overview')
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [darkMode, setDarkMode] = useState(false)

  useEffect(() => {
    loadBots()
  }, [token])

  const loadBots = async () => {
    try {
      const data = await api('/bots', {}, token!)
      setBots(data.bots || [])
    } catch (error) {
      console.error('Error loading bots:', error)
    } finally {
      setLoading(false)
    }
  }

  const selectBot = async (bot: Bot) => {
    try {
      const data = await api(`/bots?id=${bot.id}`, {}, token!)
      setSelectedBot(data.bot)
      setActiveTab('overview')
    } catch (error) {
      console.error('Error loading bot:', error)
    }
  }

  const menuItems = [
    { id: 'overview', label: 'نظرة عامة', icon: <BarChart3 className="w-5 h-5" /> },
    { id: 'bots', label: 'البوتات', icon: <Bot className="w-5 h-5" /> },
    { id: 'commands', label: 'الأوامر', icon: <Code className="w-5 h-5" /> },
    { id: 'autoreplies', label: 'الردود الآلية', icon: <MessageSquare className="w-5 h-5" /> },
    { id: 'channels', label: 'القنوات', icon: <Radio className="w-5 h-5" /> },
    { id: 'subscribers', label: 'المشتركين', icon: <Users className="w-5 h-5" /> },
    { id: 'broadcast', label: 'إرسال جماعي', icon: <Send className="w-5 h-5" /> },
    { id: 'settings', label: 'الإعدادات', icon: <Settings className="w-5 h-5" /> },
  ]

  return (
    <div className={`min-h-screen bg-background ${darkMode ? 'dark' : ''}`}>
      {/* Sidebar */}
      <aside className={`fixed top-0 right-0 h-full bg-card border-l z-40 transition-all duration-300 ${sidebarOpen ? 'w-64' : 'w-20'}`}>
        <div className="p-4 border-b">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-blue-500 flex items-center justify-center">
              <Bot className="w-6 h-6 text-white" />
            </div>
            {sidebarOpen && <span className="text-xl font-bold gradient-text">BotMaker</span>}
          </div>
        </div>

        <nav className="p-2 space-y-1">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                activeTab === item.id ? 'bg-violet-500/10 text-violet-600' : 'hover:bg-muted text-muted-foreground'
              }`}
            >
              {item.icon}
              {sidebarOpen && <span>{item.label}</span>}
            </button>
          ))}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-4 border-t">
          <div className="flex items-center justify-between">
            {sidebarOpen && (
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-500 to-blue-500 flex items-center justify-center text-white text-sm">
                  {user?.name?.[0] || user?.email[0].toUpperCase()}
                </div>
                <div className="text-sm">
                  <p className="font-medium truncate">{user?.name || 'المستخدم'}</p>
                  <p className="text-xs text-muted-foreground">{user?.plan}</p>
                </div>
              </div>
            )}
            <Button variant="ghost" size="icon" onClick={logout}>
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className={`transition-all duration-300 ${sidebarOpen ? 'mr-64' : 'mr-20'}`}>
        {/* Header */}
        <header className="sticky top-0 bg-background/80 backdrop-blur border-b z-30 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(!sidebarOpen)}>
                <Menu className="w-5 h-5" />
              </Button>
              <h1 className="text-2xl font-bold">{menuItems.find(m => m.id === activeTab)?.label}</h1>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={() => setDarkMode(!darkMode)}>
                {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </Button>
            </div>
          </div>
        </header>

        {/* Content */}
        <div className="p-6">
          {activeTab === 'overview' && <OverviewTab bots={bots} selectedBot={selectedBot} onSelectBot={selectBot} />}
          {activeTab === 'bots' && <BotsTab bots={bots} onRefresh={loadBots} onSelect={selectBot} token={token!} />}
          {activeTab === 'commands' && <CommandsTab bot={selectedBot} token={token!} />}
          {activeTab === 'autoreplies' && <AutoRepliesTab bot={selectedBot} token={token!} />}
          {activeTab === 'channels' && <ChannelsTab bot={selectedBot} token={token!} />}
          {activeTab === 'subscribers' && <SubscribersTab bot={selectedBot} token={token!} />}
          {activeTab === 'broadcast' && <BroadcastTab bot={selectedBot} token={token!} />}
          {activeTab === 'settings' && <SettingsTab bot={selectedBot} token={token!} onUpdate={() => loadBots()} />}
        </div>
      </main>
    </div>
  )
}

// Overview Tab
function OverviewTab({ bots, selectedBot, onSelectBot }: { bots: Bot[], selectedBot: Bot | null, onSelectBot: (bot: Bot) => void }) {
  const totalSubscribers = bots.reduce((sum, b) => sum + (b._count?.subscribers || b.subscribersCount || 0), 0)
  const totalMessages = bots.reduce((sum, b) => sum + (b._count?.messages || b.messagesCount || 0), 0)

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-muted-foreground">إجمالي البوتات</CardTitle></CardHeader>
          <CardContent><p className="text-3xl font-bold">{bots.length}</p></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-muted-foreground">إجمالي المشتركين</CardTitle></CardHeader>
          <CardContent><p className="text-3xl font-bold">{totalSubscribers}</p></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-muted-foreground">إجمالي الرسائل</CardTitle></CardHeader>
          <CardContent><p className="text-3xl font-bold">{totalMessages}</p></CardContent>
        </Card>
      </div>

      {/* Bots List */}
      <Card>
        <CardHeader><CardTitle>البوتات الخاصة بك</CardTitle></CardHeader>
        <CardContent>
          {bots.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">لا توجد بوتات. أنشئ بوتك الأول!</div>
          ) : (
            <div className="space-y-3">
              {bots.map((bot) => (
                <div key={bot.id} 
                  className={`p-4 rounded-lg border cursor-pointer transition-colors ${selectedBot?.id === bot.id ? 'border-violet-500 bg-violet-500/5' : 'hover:border-muted'}`}
                  onClick={() => onSelectBot(bot)}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-500 to-blue-500 flex items-center justify-center text-white">
                        <Bot className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="font-medium">{bot.name}</p>
                        <p className="text-sm text-muted-foreground">@{bot.username || 'بدون اسم'}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <Badge variant={bot.isActive ? 'default' : 'secondary'}>{bot.isActive ? 'نشط' : 'متوقف'}</Badge>
                      <div className="text-sm text-muted-foreground">
                        <Users className="w-4 h-4 inline ml-1" />{bot._count?.subscribers || bot.subscribersCount || 0}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

// Bots Tab
function BotsTab({ bots, onRefresh, onSelect, token }: { bots: Bot[], onRefresh: () => void, onSelect: (bot: Bot) => void, token: string }) {
  const [showCreate, setShowCreate] = useState(false)
  const [name, setName] = useState('')
  const [tokenInput, setTokenInput] = useState('')
  const [description, setDescription] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const createBot = async () => {
    if (!name || !tokenInput) {
      setError('الاسم والتوكن مطلوبان')
      return
    }

    setLoading(true)
    setError('')

    try {
      await api('/bots', {
        method: 'POST',
        body: JSON.stringify({ name, token: tokenInput, description }),
      }, token)
      
      setName('')
      setTokenInput('')
      setDescription('')
      setShowCreate(false)
      onRefresh()
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const deleteBot = async (botId: string) => {
    if (!confirm('هل أنت متأكد من حذف هذا البوت؟')) return

    try {
      await api(`/bots?id=${botId}`, { method: 'DELETE' }, token)
      onRefresh()
    } catch (err: any) {
      alert(err.message)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <p className="text-muted-foreground">إدارة بوتات التليجرام الخاصة بك</p>
        <Button onClick={() => setShowCreate(true)} className="bg-gradient-to-r from-violet-500 to-blue-500 text-white">
          <Plus className="w-4 h-4 ml-2" />إنشاء بوت جديد
        </Button>
      </div>

      {/* Create Bot Dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>إنشاء بوت جديد</DialogTitle>
            <DialogDescription>أدخل بيانات البوت للإنشاء</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {error && <Alert variant="destructive"><AlertDescription>{error}</AlertDescription></Alert>}
            <div className="space-y-2">
              <Label>اسم البوت</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="بوت المتجر" />
            </div>
            <div className="space-y-2">
              <Label>توكن البوت</Label>
              <Input value={tokenInput} onChange={(e) => setTokenInput(e.target.value)} placeholder="123456789:ABCdef..." className="font-mono text-sm" />
              <p className="text-xs text-muted-foreground">احصل على التوكن من <span className="text-violet-500">@BotFather</span> في تليجرام</p>
            </div>
            <div className="space-y-2">
              <Label>الوصف (اختياري)</Label>
              <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="وصف مختصر..." />
            </div>
            <Button onClick={createBot} disabled={loading} className="w-full bg-gradient-to-r from-violet-500 to-blue-500 text-white">
              {loading ? 'جاري الإنشاء...' : 'إنشاء البوت'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Bots List */}
      <div className="grid gap-4">
        {bots.map((bot) => (
          <Card key={bot.id} className="cursor-pointer hover:border-violet-500/50 transition-colors" onClick={() => onSelect(bot)}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-violet-500 to-blue-500 flex items-center justify-center text-white">
                    <Bot className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold">{bot.name}</h3>
                    <p className="text-sm text-muted-foreground">@{bot.username || 'بدون اسم'}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant={bot.isActive ? 'default' : 'secondary'}>{bot.isActive ? 'نشط' : 'متوقف'}</Badge>
                  <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); deleteBot(bot.id) }}>
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

// Commands Tab
function CommandsTab({ bot, token }: { bot: Bot | null, token: string }) {
  const [commands, setCommands] = useState<BotCommand[]>([])
  const [loading, setLoading] = useState(false)
  const [showAdd, setShowAdd] = useState(false)
  const [form, setForm] = useState({ command: '', description: '', response: '' })

  useEffect(() => {
    if (bot) loadCommands()
  }, [bot])

  const loadCommands = async () => {
    setLoading(true)
    try {
      const data = await api(`/commands?botId=${bot!.id}`, {}, token)
      setCommands(data.commands || [])
    } catch (error) {
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  const addCommand = async () => {
    try {
      await api('/commands', {
        method: 'POST',
        body: JSON.stringify({ botId: bot!.id, ...form }),
      }, token)
      setForm({ command: '', description: '', response: '' })
      setShowAdd(false)
      loadCommands()
    } catch (err: any) {
      alert(err.message)
    }
  }

  const deleteCommand = async (id: string) => {
    if (!confirm('حذف هذا الأمر؟')) return
    try {
      await api(`/commands?id=${id}`, { method: 'DELETE' }, token)
      loadCommands()
    } catch (err: any) {
      alert(err.message)
    }
  }

  if (!bot) return <div className="text-center py-12 text-muted-foreground">اختر بوت أولاً</div>

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <p className="text-muted-foreground">إدارة أوامر البوت: <span className="font-medium text-foreground">{bot.name}</span></p>
        <Button onClick={() => setShowAdd(true)} className="bg-gradient-to-r from-violet-500 to-blue-500 text-white">
          <Plus className="w-4 h-4 ml-2" />إضافة أمر
        </Button>
      </div>

      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent>
          <DialogHeader><DialogTitle>إضافة أمر جديد</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>الأمر (بدون /)</Label>
              <Input value={form.command} onChange={(e) => setForm({...form, command: e.target.value})} placeholder="info" />
            </div>
            <div className="space-y-2">
              <Label>الوصف</Label>
              <Input value={form.description} onChange={(e) => setForm({...form, description: e.target.value})} placeholder="عرض المعلومات" />
            </div>
            <div className="space-y-2">
              <Label>الرد</Label>
              <Textarea value={form.response} onChange={(e) => setForm({...form, response: e.target.value})} placeholder="هذا هو الرد..." />
            </div>
            <Button onClick={addCommand} className="w-full bg-gradient-to-r from-violet-500 to-blue-500 text-white">إضافة</Button>
          </div>
        </DialogContent>
      </Dialog>

      <div className="space-y-3">
        {commands.map((cmd) => (
          <Card key={cmd.id}>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="font-mono font-medium">/{cmd.command}</p>
                <p className="text-sm text-muted-foreground">{cmd.description || cmd.response.slice(0, 50)}...</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant={cmd.isActive ? 'default' : 'secondary'}>{cmd.isActive ? 'نشط' : 'متوقف'}</Badge>
                <Button variant="ghost" size="icon" onClick={() => deleteCommand(cmd.id)}>
                  <Trash2 className="w-4 h-4 text-red-500" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
        {commands.length === 0 && <div className="text-center py-8 text-muted-foreground">لا توجد أوامر</div>}
      </div>
    </div>
  )
}

// Auto Replies Tab
function AutoRepliesTab({ bot, token }: { bot: Bot | null, token: string }) {
  const [replies, setReplies] = useState<AutoReply[]>([])
  const [showAdd, setShowAdd] = useState(false)
  const [form, setForm] = useState({ keyword: '', matchType: 'contains', response: '' })

  const loadReplies = async () => {
    if (!bot) return
    try {
      const data = await api(`/autoreplies?botId=${bot.id}`, {}, token)
      setReplies(data.autoReplies || [])
    } catch (error) {
      console.error(error)
    }
  }

  useEffect(() => {
    if (bot) {
      // Use microtask to avoid synchronous setState in effect
      Promise.resolve().then(() => loadReplies())
    }
  }, [bot])

  const addReply = async () => {
    try {
      await api('/autoreplies', {
        method: 'POST',
        body: JSON.stringify({ botId: bot!.id, ...form }),
      }, token)
      setForm({ keyword: '', matchType: 'contains', response: '' })
      setShowAdd(false)
      loadReplies()
    } catch (err: any) {
      alert(err.message)
    }
  }

  const deleteReply = async (id: string) => {
    if (!confirm('حذف هذا الرد؟')) return
    try {
      await api(`/autoreplies?id=${id}`, { method: 'DELETE' }, token)
      loadReplies()
    } catch (err: any) {
      alert(err.message)
    }
  }

  if (!bot) return <div className="text-center py-12 text-muted-foreground">اختر بوت أولاً</div>

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <p className="text-muted-foreground">الردود الآلية التلقائية</p>
        <Button onClick={() => setShowAdd(true)} className="bg-gradient-to-r from-violet-500 to-blue-500 text-white">
          <Plus className="w-4 h-4 ml-2" />إضافة رد
        </Button>
      </div>

      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent>
          <DialogHeader><DialogTitle>إضافة رد آلي</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>الكلمة المفتاحية</Label>
              <Input value={form.keyword} onChange={(e) => setForm({...form, keyword: e.target.value})} placeholder="مرحبا" />
            </div>
            <div className="space-y-2">
              <Label>نوع المطابقة</Label>
              <Select value={form.matchType} onValueChange={(v) => setForm({...form, matchType: v})}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="exact">مطابق تماماً</SelectItem>
                  <SelectItem value="contains">يحتوي</SelectItem>
                  <SelectItem value="starts_with">يبدأ بـ</SelectItem>
                  <SelectItem value="regex">تعبير نمطي</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>الرد</Label>
              <Textarea value={form.response} onChange={(e) => setForm({...form, response: e.target.value})} placeholder="أهلاً بك!" />
            </div>
            <Button onClick={addReply} className="w-full bg-gradient-to-r from-violet-500 to-blue-500 text-white">إضافة</Button>
          </div>
        </DialogContent>
      </Dialog>

      <div className="space-y-3">
        {replies.map((reply) => (
          <Card key={reply.id}>
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <p className="font-medium">"{reply.keyword}"</p>
                <p className="text-sm text-muted-foreground">→ {reply.response.slice(0, 50)}...</p>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline">{reply.matchType}</Badge>
                <Button variant="ghost" size="icon" onClick={() => deleteReply(reply.id)}>
                  <Trash2 className="w-4 h-4 text-red-500" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
        {replies.length === 0 && <div className="text-center py-8 text-muted-foreground">لا توجد ردود آلية</div>}
      </div>
    </div>
  )
}

// Channels Tab
function ChannelsTab({ bot, token }: { bot: Bot | null, token: string }) {
  const [channels, setChannels] = useState<Channel[]>([])

  const loadChannels = async () => {
    if (!bot) return
    try {
      const data = await api(`/channels?botId=${bot.id}`, {}, token)
      setChannels(data.channels || [])
    } catch (error) {
      console.error(error)
    }
  }

  useEffect(() => {
    if (bot) {
      // Use microtask to avoid synchronous setState in effect
      Promise.resolve().then(() => loadChannels())
    }
  }, [bot])

  if (!bot) return <div className="text-center py-12 text-muted-foreground">اختر بوت أولاً</div>

  return (
    <div className="space-y-6">
      <Alert>
        <AlertDescription>
          <strong>كيفية ربط البوت بقناة:</strong><br />
          1. اذهب إلى قناتك في تليجرام<br />
          2. اضغط على معلومات القناة ← المشرفون<br />
          3. أضف البوت كمشرف مع صلاحية النشر<br />
          4. سيتم ربط القناة تلقائياً
        </AlertDescription>
      </Alert>

      <div className="space-y-3">
        {channels.map((channel) => (
          <Card key={channel.id}>
            <CardContent className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center text-white">
                  <Radio className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-medium">{channel.title}</p>
                  <p className="text-sm text-muted-foreground">@{channel.username || channel.channelId}</p>
                </div>
              </div>
              <Badge variant={channel.isActive ? 'default' : 'secondary'}>{channel.isActive ? 'مرتبط' : 'غير مرتبط'}</Badge>
            </CardContent>
          </Card>
        ))}
        {channels.length === 0 && <div className="text-center py-8 text-muted-foreground">لا توجد قنوات مرتبطة. أضف البوت كمشرف في قناتك.</div>}
      </div>
    </div>
  )
}

// Subscribers Tab
function SubscribersTab({ bot, token }: { bot: Bot | null, token: string }) {
  const [subscribers, setSubscribers] = useState<Subscriber[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (bot) loadSubscribers()
  }, [bot])

  const loadSubscribers = async () => {
    setLoading(true)
    try {
      const data = await api(`/broadcast?botId=${bot!.id}`, {}, token)
      setSubscribers(data.subscribers || [])
    } catch (error) {
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  if (!bot) return <div className="text-center py-12 text-muted-foreground">اختر بوت أولاً</div>

  return (
    <div className="space-y-6">
      <p className="text-muted-foreground">المشتركين في البوت: {subscribers.length}</p>

      <div className="space-y-3">
        {subscribers.map((sub) => (
          <Card key={sub.id}>
            <CardContent className="p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-500 to-blue-500 flex items-center justify-center text-white font-bold">
                  {sub.firstName?.[0] || sub.username?.[0] || '?'}
                </div>
                <div>
                  <p className="font-medium">{sub.firstName} {sub.lastName}</p>
                  <p className="text-sm text-muted-foreground">@{sub.username || 'بدون اسم'}</p>
                </div>
              </div>
              <Badge variant={sub.isBlocked ? 'destructive' : 'default'}>{sub.isBlocked ? 'محظور' : 'نشط'}</Badge>
            </CardContent>
          </Card>
        ))}
        {subscribers.length === 0 && <div className="text-center py-8 text-muted-foreground">لا يوجد مشتركين بعد</div>}
      </div>
    </div>
  )
}

// Broadcast Tab
function BroadcastTab({ bot, token }: { bot: Bot | null, token: string }) {
  const [message, setMessage] = useState('')
  const [sending, setSending] = useState(false)
  const [result, setResult] = useState<any>(null)

  const sendBroadcast = async () => {
    if (!message.trim()) return
    
    setSending(true)
    setResult(null)
    
    try {
      const data = await api('/broadcast', {
        method: 'POST',
        body: JSON.stringify({
          botId: bot!.id,
          message,
          type: 'text',
          targetType: 'all',
        }),
      }, token)
      setResult(data)
      setMessage('')
    } catch (err: any) {
      alert(err.message)
    } finally {
      setSending(false)
    }
  }

  if (!bot) return <div className="text-center py-12 text-muted-foreground">اختر بوت أولاً</div>

  return (
    <div className="space-y-6">
      <Alert>
        <AlertDescription>أرسل رسالة لجميع مشتركي البوت دفعة واحدة</AlertDescription>
      </Alert>

      <Card>
        <CardHeader><CardTitle>رسالة جماعية</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="اكتب رسالتك هنا... يمكنك استخدام HTML للتنسيق"
            className="min-h-[150px]"
          />
          <Button onClick={sendBroadcast} disabled={sending || !message.trim()} className="w-full bg-gradient-to-r from-violet-500 to-blue-500 text-white">
            {sending ? 'جاري الإرسال...' : <><Send className="w-4 h-4 ml-2" />إرسال للجميع</>}
          </Button>
        </CardContent>
      </Card>

      {result && (
        <Card>
          <CardHeader><CardTitle>نتيجة الإرسال</CardTitle></CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div><p className="text-2xl font-bold">{result.stats?.total || 0}</p><p className="text-sm text-muted-foreground">إجمالي</p></div>
              <div><p className="text-2xl font-bold text-green-500">{result.stats?.sent || 0}</p><p className="text-sm text-muted-foreground">تم الإرسال</p></div>
              <div><p className="text-2xl font-bold text-red-500">{result.stats?.failed || 0}</p><p className="text-sm text-muted-foreground">فشل</p></div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

// Settings Tab
function SettingsTab({ bot, token, onUpdate }: { bot: Bot | null, token: string, onUpdate: () => void }) {
  const [form, setForm] = useState({ name: '', description: '', welcomeMessage: '' })
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (bot) {
      setForm({
        name: bot.name,
        description: bot.description || '',
        welcomeMessage: bot.welcomeMessage || '',
      })
    }
  }, [bot])

  const saveSettings = async () => {
    setSaving(true)
    try {
      await api('/bots', {
        method: 'PUT',
        body: JSON.stringify({ id: bot!.id, ...form }),
      }, token)
      onUpdate()
      alert('تم الحفظ!')
    } catch (err: any) {
      alert(err.message)
    } finally {
      setSaving(false)
    }
  }

  const toggleBot = async () => {
    try {
      await api('/bots', {
        method: 'PUT',
        body: JSON.stringify({ id: bot!.id, isActive: !bot!.isActive }),
      }, token)
      onUpdate()
    } catch (err: any) {
      alert(err.message)
    }
  }

  if (!bot) return <div className="text-center py-12 text-muted-foreground">اختر بوت أولاً</div>

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader><CardTitle>إعدادات البوت</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>اسم البوت</Label>
            <Input value={form.name} onChange={(e) => setForm({...form, name: e.target.value})} />
          </div>
          <div className="space-y-2">
            <Label>الوصف</Label>
            <Textarea value={form.description} onChange={(e) => setForm({...form, description: e.target.value})} />
          </div>
          <div className="space-y-2">
            <Label>رسالة الترحيب</Label>
            <Textarea value={form.welcomeMessage} onChange={(e) => setForm({...form, welcomeMessage: e.target.value})} />
          </div>
          <Button onClick={saveSettings} disabled={saving} className="bg-gradient-to-r from-violet-500 to-blue-500 text-white">
            {saving ? 'جاري الحفظ...' : 'حفظ الإعدادات'}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>حالة البوت</CardTitle></CardHeader>
        <CardContent className="flex items-center justify-between">
          <div>
            <p className="font-medium">{bot.isActive ? 'البوت نشط' : 'البوت متوقف'}</p>
            <p className="text-sm text-muted-foreground">{bot.isActive ? 'يستقبل ويرسل الرسائل' : 'متوقف عن العمل'}</p>
          </div>
          <Button onClick={toggleBot} variant={bot.isActive ? 'destructive' : 'default'}>
            {bot.isActive ? 'إيقاف البوت' : 'تشغيل البوت'}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>معلومات البوت</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          <div className="flex justify-between"><span className="text-muted-foreground">المعرف:</span><span className="font-mono">{bot.id}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">اسم المستخدم:</span><span>@{bot.username || '-'}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">المشتركين:</span><span>{bot.subscribersCount}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">الرسائل:</span><span>{bot.messagesCount}</span></div>
          <div className="flex justify-between"><span className="text-muted-foreground">تاريخ الإنشاء:</span><span>{new Date(bot.createdAt).toLocaleDateString('ar')}</span></div>
        </CardContent>
      </Card>
    </div>
  )
}

// Main App
export default function Home() {
  const [user, setUser] = useState<User | null>(null)
  const [token, setToken] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [showAuth, setShowAuth] = useState(false)

  useEffect(() => {
    // Check for existing session
    const savedToken = localStorage.getItem('token')
    if (savedToken) {
      api('/auth', {
        method: 'POST',
        body: JSON.stringify({ action: 'me' }),
      }, savedToken)
        .then((data) => {
          setUser(data.user)
          setToken(savedToken)
        })
        .catch(() => {
          localStorage.removeItem('token')
        })
        .finally(() => setLoading(false))
    } else {
      // Use microtask to avoid synchronous setState in effect
      Promise.resolve().then(() => setLoading(false))
    }
  }, [])

  const login = async (email: string, password: string) => {
    const data = await api('/auth', {
      method: 'POST',
      body: JSON.stringify({ action: 'login', email, password }),
    })
    setUser(data.user)
    setToken(data.token)
    localStorage.setItem('token', data.token)
  }

  const register = async (email: string, password: string, name?: string) => {
    const data = await api('/auth', {
      method: 'POST',
      body: JSON.stringify({ action: 'register', email, password, name }),
    })
    setUser(data.user)
    setToken(data.token)
    localStorage.setItem('token', data.token)
  }

  const logout = () => {
    setUser(null)
    setToken(null)
    localStorage.removeItem('token')
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-500 to-blue-500 flex items-center justify-center mx-auto mb-4 animate-pulse">
            <Bot className="w-8 h-8 text-white" />
          </div>
          <p className="text-muted-foreground">جاري التحميل...</p>
        </div>
      </div>
    )
  }

  return (
    <AuthContext.Provider value={{ user, token, login, register, logout, loading }}>
      {user && token ? (
        <Dashboard />
      ) : showAuth ? (
        <AuthForm onSuccess={() => setShowAuth(false)} />
      ) : (
        <LandingPage onGetStarted={() => setShowAuth(true)} />
      )}
    </AuthContext.Provider>
  )
}
