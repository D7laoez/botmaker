import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { TelegramBotAPI } from '@/lib/telegram'

// Get user from session
async function getUser(request: NextRequest) {
  const authHeader = request.headers.get('authorization')
  const token = authHeader?.replace('Bearer ', '')
  
  if (!token) return null

  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  })

  if (!session || session.expiresAt < new Date()) {
    return null
  }

  return session.user
}

// GET /api/commands - Get bot commands
export async function GET(request: NextRequest) {
  try {
    const user = await getUser(request)
    if (!user) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const botId = searchParams.get('botId')

    if (!botId) {
      return NextResponse.json({ error: 'معرف البوت مطلوب' }, { status: 400 })
    }

    const bot = await db.bot.findFirst({
      where: { id: botId, userId: user.id },
    })

    if (!bot) {
      return NextResponse.json({ error: 'البوت غير موجود' }, { status: 404 })
    }

    const commands = await db.botCommand.findMany({
      where: { botId },
      orderBy: { command: 'asc' },
    })

    return NextResponse.json({ commands })
  } catch (error: any) {
    console.error('Get commands error:', error)
    return NextResponse.json({ error: 'حدث خطأ في الخادم' }, { status: 500 })
  }
}

// POST /api/commands - Create command
export async function POST(request: NextRequest) {
  try {
    const user = await getUser(request)
    if (!user) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
    }

    const body = await request.json()
    const { botId, command, description, response, responseType, mediaUrl, isActive } = body

    if (!botId || !command || !response) {
      return NextResponse.json({ error: 'جميع الحقول مطلوبة' }, { status: 400 })
    }

    const bot = await db.bot.findFirst({
      where: { id: botId, userId: user.id },
    })

    if (!bot) {
      return NextResponse.json({ error: 'البوت غير موجود' }, { status: 404 })
    }

    const cleanCommand = command.replace(/^\//, '').toLowerCase()

    const existing = await db.botCommand.findUnique({
      where: { botId_command: { botId, command: cleanCommand } },
    })

    if (existing) {
      return NextResponse.json({ error: 'هذا الأمر موجود بالفعل' }, { status: 400 })
    }

    const newCommand = await db.botCommand.create({
      data: {
        botId,
        command: cleanCommand,
        description,
        response,
        responseType: responseType || 'text',
        mediaUrl,
        isActive: isActive ?? true,
      },
    })

    // Update Telegram bot commands
    try {
      const telegram = new TelegramBotAPI(bot.token)
      const allCommands = await db.botCommand.findMany({
        where: { botId, isActive: true },
        select: { command: true, description: true },
      })
      await telegram.setMyCommands(allCommands.map(c => ({
        command: c.command,
        description: c.description || c.command,
      })))
    } catch (e) {
      console.error('Failed to update Telegram commands:', e)
    }

    return NextResponse.json({ success: true, command: newCommand })
  } catch (error: any) {
    console.error('Create command error:', error)
    return NextResponse.json({ error: 'حدث خطأ في الخادم' }, { status: 500 })
  }
}

// PUT /api/commands - Update command
export async function PUT(request: NextRequest) {
  try {
    const user = await getUser(request)
    if (!user) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
    }

    const body = await request.json()
    const { id, command, description, response, responseType, mediaUrl, isActive } = body

    if (!id) {
      return NextResponse.json({ error: 'معرف الأمر مطلوب' }, { status: 400 })
    }

    const existingCommand = await db.botCommand.findUnique({
      where: { id },
      include: { bot: true },
    })

    if (!existingCommand || existingCommand.bot.userId !== user.id) {
      return NextResponse.json({ error: 'الأمر غير موجود' }, { status: 404 })
    }

    const updatedCommand = await db.botCommand.update({
      where: { id },
      data: {
        command: command?.replace(/^\//, '').toLowerCase(),
        description,
        response,
        responseType,
        mediaUrl,
        isActive,
      },
    })

    return NextResponse.json({ success: true, command: updatedCommand })
  } catch (error: any) {
    console.error('Update command error:', error)
    return NextResponse.json({ error: 'حدث خطأ في الخادم' }, { status: 500 })
  }
}

// DELETE /api/commands - Delete command
export async function DELETE(request: NextRequest) {
  try {
    const user = await getUser(request)
    if (!user) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'معرف الأمر مطلوب' }, { status: 400 })
    }

    const command = await db.botCommand.findUnique({
      where: { id },
      include: { bot: true },
    })

    if (!command || command.bot.userId !== user.id) {
      return NextResponse.json({ error: 'الأمر غير موجود' }, { status: 404 })
    }

    await db.botCommand.delete({ where: { id } })

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('Delete command error:', error)
    return NextResponse.json({ error: 'حدث خطأ في الخادم' }, { status: 500 })
  }
}
