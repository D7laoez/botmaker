import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { TelegramBotAPI } from '@/lib/telegram'

// Get user from session
async function getUser(request: NextRequest) {
  const authHeader = request.headers.get('authorization')
  const token = authHeader?.replace('Bearer ', '')
  
  if (!token) return null

  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  })

  if (!session || session.expiresAt < new Date()) {
    return null
  }

  return session.user
}

// GET /api/bots - Get all user's bots
export async function GET(request: NextRequest) {
  try {
    const user = await getUser(request)
    if (!user) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const botId = searchParams.get('id')

    if (botId) {
      // Get single bot with details
      const bot = await db.bot.findFirst({
        where: { id: botId, userId: user.id },
        include: {
          commands: { orderBy: { command: 'asc' } },
          autoReplies: { orderBy: { priority: 'desc' } },
          channels: { where: { isActive: true } },
          _count: {
            select: { subscribers: true, messages: true }
          }
        },
      })

      if (!bot) {
        return NextResponse.json({ error: 'البوت غير موجود' }, { status: 404 })
      }

      return NextResponse.json({ bot })
    }

    // Get all bots
    const bots = await db.bot.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      include: {
        _count: {
          select: { subscribers: true, messages: true, channels: true }
        }
      }
    })

    return NextResponse.json({ bots })
  } catch (error: any) {
    console.error('Get bots error:', error)
    return NextResponse.json({ error: 'حدث خطأ في الخادم' }, { status: 500 })
  }
}

// POST /api/bots - Create new bot
export async function POST(request: NextRequest) {
  try {
    const user = await getUser(request)
    if (!user) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
    }

    const body = await request.json()
    const { name, token, description, welcomeMessage } = body

    if (!name || !token) {
      return NextResponse.json({ error: 'اسم البوت والتوكن مطلوبان' }, { status: 400 })
    }

    // Check if token already exists
    const existingBot = await db.bot.findUnique({
      where: { token },
    })

    if (existingBot) {
      return NextResponse.json({ error: 'هذا التوكن مستخدم بالفعل' }, { status: 400 })
    }

    // Validate token with Telegram
    const telegram = new TelegramBotAPI(token)
    const validation = await telegram.validateToken()

    if (!validation.valid) {
      return NextResponse.json({ error: 'توكن غير صالح: ' + validation.error }, { status: 400 })
    }

    // Check user's bot limit based on plan
    const botsCount = await db.bot.count({ where: { userId: user.id } })
    const limits: Record<string, number> = {
      free: 1,
      pro: 10,
      enterprise: 100,
    }
    
    if (botsCount >= (limits[user.plan] || 1)) {
      return NextResponse.json({ 
        error: `لقد وصلت للحد الأقصى من البوتات (${limits[user.plan]}). قم بالترقية لإنشاء المزيد.` 
      }, { status: 400 })
    }

    // Create bot
    const bot = await db.bot.create({
      data: {
        userId: user.id,
        name,
        token,
        username: validation.botInfo?.username,
        description,
        welcomeMessage: welcomeMessage || 'مرحباً بك! كيف يمكنني مساعدتك؟',
      },
    })

    // Set default commands
    await db.botCommand.createMany({
      data: [
        {
          botId: bot.id,
          command: 'start',
          description: 'بدء استخدام البوت',
          response: welcomeMessage || 'مرحباً بك! كيف يمكنني مساعدتك؟',
        },
        {
          botId: bot.id,
          command: 'help',
          description: 'عرض المساعدة',
          response: 'قائمة الأوامر المتاحة:\n/start - بدء استخدام البوت\n/help - عرض هذه المساعدة',
        },
      ],
    })

    // Set webhook
    const webhookUrl = `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/api/webhook/${bot.id}`
    try {
      await telegram.setWebhook(webhookUrl)
      await db.bot.update({
        where: { id: bot.id },
        data: { webhookUrl },
      })
    } catch (webhookError) {
      console.error('Webhook setup error:', webhookError)
    }

    return NextResponse.json({ 
      success: true, 
      bot,
      botInfo: validation.botInfo 
    })
  } catch (error: any) {
    console.error('Create bot error:', error)
    return NextResponse.json({ error: 'حدث خطأ في الخادم' }, { status: 500 })
  }
}

// PUT /api/bots - Update bot
export async function PUT(request: NextRequest) {
  try {
    const user = await getUser(request)
    if (!user) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
    }

    const body = await request.json()
    const { id, name, description, welcomeMessage, isActive } = body

    if (!id) {
      return NextResponse.json({ error: 'معرف البوت مطلوب' }, { status: 400 })
    }

    const bot = await db.bot.findFirst({
      where: { id, userId: user.id },
    })

    if (!bot) {
      return NextResponse.json({ error: 'البوت غير موجود' }, { status: 404 })
    }

    const updatedBot = await db.bot.update({
      where: { id },
      data: {
        name,
        description,
        welcomeMessage,
        isActive,
      },
    })

    return NextResponse.json({ success: true, bot: updatedBot })
  } catch (error: any) {
    console.error('Update bot error:', error)
    return NextResponse.json({ error: 'حدث خطأ في الخادم' }, { status: 500 })
  }
}

// DELETE /api/bots - Delete bot
export async function DELETE(request: NextRequest) {
  try {
    const user = await getUser(request)
    if (!user) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const botId = searchParams.get('id')

    if (!botId) {
      return NextResponse.json({ error: 'معرف البوت مطلوب' }, { status: 400 })
    }

    const bot = await db.bot.findFirst({
      where: { id: botId, userId: user.id },
    })

    if (!bot) {
      return NextResponse.json({ error: 'البوت غير موجود' }, { status: 404 })
    }

    // Delete webhook from Telegram
    try {
      const telegram = new TelegramBotAPI(bot.token)
      await telegram.deleteWebhook()
    } catch (e) {
      console.error('Error deleting webhook:', e)
    }

    // Delete bot (cascade will delete related records)
    await db.bot.delete({
      where: { id: botId },
    })

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('Delete bot error:', error)
    return NextResponse.json({ error: 'حدث خطأ في الخادم' }, { status: 500 })
  }
}
