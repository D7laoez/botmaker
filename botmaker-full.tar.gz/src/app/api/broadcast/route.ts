import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { TelegramBotAPI } from '@/lib/telegram'

// Get user from session
async function getUser(request: NextRequest) {
  const authHeader = request.headers.get('authorization')
  const token = authHeader?.replace('Bearer ', '')
  
  if (!token) return null

  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  })

  if (!session || session.expiresAt < new Date()) {
    return null
  }

  return session.user
}

// POST - Broadcast message to all subscribers
export async function POST(request: NextRequest) {
  try {
    const user = await getUser(request)
    if (!user) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
    }

    const body = await request.json()
    const { botId, message, type, mediaUrl, targetType, targetIds } = body

    if (!botId || !message) {
      return NextResponse.json({ error: 'معرف البوت والرسالة مطلوبان' }, { status: 400 })
    }

    const bot = await db.bot.findFirst({
      where: { id: botId, userId: user.id },
    })

    if (!bot) {
      return NextResponse.json({ error: 'البوت غير موجود' }, { status: 404 })
    }

    // Check user's message limit
    const userWithBots = await db.user.findUnique({
      where: { id: user.id },
      include: {
        bots: {
          select: { messagesCount: true }
        }
      }
    })

    const totalMessages = userWithBots?.bots.reduce((sum, b) => sum + b.messagesCount, 0) || 0
    const limits: Record<string, number> = {
      free: 500,
      pro: 50000,
      enterprise: 1000000,
    }

    if (totalMessages > (limits[user.plan] || 500)) {
      return NextResponse.json({ 
        error: `لقد تجاوزت حد الرسائل الشهرية (${limits[user.plan]}). قم بالترقية للمتابعة.` 
      }, { status: 400 })
    }

    const telegram = new TelegramBotAPI(bot.token)

    // Get target subscribers
    let subscribers: { telegramId: string }[] = []
    
    if (targetType === 'all') {
      subscribers = await db.subscriber.findMany({
        where: { botId, isBlocked: false },
        select: { telegramId: true },
      })
    } else if (targetType === 'selected' && targetIds?.length > 0) {
      subscribers = await db.subscriber.findMany({
        where: { 
          botId, 
          isBlocked: false,
          id: { in: targetIds }
        },
        select: { telegramId: true },
      })
    }

    if (subscribers.length === 0) {
      return NextResponse.json({ error: 'لا يوجد مشتركين للإرسال إليهم' }, { status: 400 })
    }

    // Send messages (with rate limiting)
    let sent = 0
    let failed = 0
    const errors: string[] = []

    for (const subscriber of subscribers) {
      try {
        const chatId = Number(subscriber.telegramId)
        
        if (type === 'photo' && mediaUrl) {
          await telegram.sendPhoto(chatId, mediaUrl, message)
        } else if (type === 'video' && mediaUrl) {
          await telegram.sendVideo(chatId, mediaUrl, message)
        } else if (type === 'document' && mediaUrl) {
          await telegram.sendDocument(chatId, mediaUrl, message)
        } else {
          await telegram.sendMessage(chatId, message, { parse_mode: 'HTML' })
        }
        
        sent++
        
        // Rate limiting (30 messages per second max)
        if (sent % 25 === 0) {
          await new Promise(resolve => setTimeout(resolve, 1000))
        }
      } catch (error: any) {
        failed++
        if (errors.length < 10) {
          errors.push(`${subscriber.telegramId}: ${error.message}`)
        }

        // Mark as blocked if user blocked the bot
        if (error.message?.includes('blocked') || error.message?.includes('deactivated')) {
          await db.subscriber.updateMany({
            where: { botId, telegramId: subscriber.telegramId },
            data: { isBlocked: true },
          })
        }
      }
    }

    // Update message count
    await db.bot.update({
      where: { id: botId },
      data: { messagesCount: { increment: sent } },
    })

    return NextResponse.json({
      success: true,
      stats: {
        total: subscribers.length,
        sent,
        failed,
      },
      errors: errors.length > 0 ? errors : undefined,
    })
  } catch (error: any) {
    console.error('Broadcast error:', error)
    return NextResponse.json({ error: error.message || 'حدث خطأ في الخادم' }, { status: 500 })
  }
}

// GET - Get subscribers list
export async function GET(request: NextRequest) {
  try {
    const user = await getUser(request)
    if (!user) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const botId = searchParams.get('botId')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '50')
    const search = searchParams.get('search')

    if (!botId) {
      return NextResponse.json({ error: 'معرف البوت مطلوب' }, { status: 400 })
    }

    const bot = await db.bot.findFirst({
      where: { id: botId, userId: user.id },
    })

    if (!bot) {
      return NextResponse.json({ error: 'البوت غير موجود' }, { status: 404 })
    }

    const where: any = { botId }
    if (search) {
      where.OR = [
        { username: { contains: search } },
        { firstName: { contains: search } },
        { lastName: { contains: search } },
      ]
    }

    const [subscribers, total] = await Promise.all([
      db.subscriber.findMany({
        where,
        orderBy: { subscribedAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      db.subscriber.count({ where }),
    ])

    return NextResponse.json({
      subscribers,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error: any) {
    console.error('Get subscribers error:', error)
    return NextResponse.json({ error: 'حدث خطأ في الخادم' }, { status: 500 })
  }
}
