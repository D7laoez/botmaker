import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { randomBytes, createHash } from 'crypto'

// Hash password with salt
function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex')
  const hash = createHash('sha256').update(password + salt).digest('hex')
  return `${salt}:${hash}`
}

// Verify password
function verifyPassword(password: string, storedHash: string): boolean {
  const [salt, hash] = storedHash.split(':')
  const verifyHash = createHash('sha256').update(password + salt).digest('hex')
  return hash === verifyHash
}

// Generate session token
function generateToken(): string {
  return randomBytes(32).toString('hex')
}

// Get user from session
async function getUser(request: NextRequest) {
  const authHeader = request.headers.get('authorization')
  const token = authHeader?.replace('Bearer ', '')
  
  if (!token) return null

  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  })

  if (!session || session.expiresAt < new Date()) {
    return null
  }

  return session.user
}

// POST /api/auth/register - Register new user
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action, email, password, name, phone, token } = body

    // Register
    if (action === 'register') {
      if (!email || !password) {
        return NextResponse.json(
          { error: 'البريد الإلكتروني وكلمة المرور مطلوبان' },
          { status: 400 }
        )
      }

      // Check if user exists
      const existingUser = await db.user.findUnique({
        where: { email },
      })

      if (existingUser) {
        return NextResponse.json(
          { error: 'البريد الإلكتروني مستخدم بالفعل' },
          { status: 400 }
        )
      }

      // Create user
      const hashedPassword = hashPassword(password)
      const user = await db.user.create({
        data: {
          email,
          password: hashedPassword,
          name,
          phone,
        },
      })

      // Create session
      const sessionToken = generateToken()
      const expiresAt = new Date()
      expiresAt.setDate(expiresAt.getDate() + 30) // 30 days

      await db.session.create({
        data: {
          userId: user.id,
          token: sessionToken,
          expiresAt,
        },
      })

      return NextResponse.json({
        success: true,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          plan: user.plan,
        },
        token: sessionToken,
      })
    }

    // Login
    if (action === 'login') {
      if (!email || !password) {
        return NextResponse.json(
          { error: 'البريد الإلكتروني وكلمة المرور مطلوبان' },
          { status: 400 }
        )
      }

      // Find user
      const user = await db.user.findUnique({
        where: { email },
      })

      if (!user || !verifyPassword(password, user.password)) {
        return NextResponse.json(
          { error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' },
          { status: 401 }
        )
      }

      // Create session
      const sessionToken = generateToken()
      const expiresAt = new Date()
      expiresAt.setDate(expiresAt.getDate() + 30)

      await db.session.create({
        data: {
          userId: user.id,
          token: sessionToken,
          expiresAt,
        },
      })

      return NextResponse.json({
        success: true,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          plan: user.plan,
          credits: user.credits,
        },
        token: sessionToken,
      })
    }

    // Logout
    if (action === 'logout') {
      const authHeader = request.headers.get('authorization')
      const sessionToken = authHeader?.replace('Bearer ', '') || token

      if (sessionToken) {
        await db.session.deleteMany({
          where: { token: sessionToken },
        })
      }

      return NextResponse.json({ success: true })
    }

    // Get current user
    if (action === 'me') {
      const user = await getUser(request)
      
      if (!user) {
        return NextResponse.json(
          { error: 'غير مصرح' },
          { status: 401 }
        )
      }

      return NextResponse.json({
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          plan: user.plan,
          credits: user.credits,
        },
      })
    }

    return NextResponse.json(
      { error: 'إجراء غير معروف' },
      { status: 400 }
    )
  } catch (error: any) {
    console.error('Auth error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ في الخادم' },
      { status: 500 }
    )
  }
}

// GET /api/auth/me - Get current user
export async function GET(request: NextRequest) {
  try {
    const user = await getUser(request)
    
    if (!user) {
      return NextResponse.json(
        { error: 'غير مصرح' },
        { status: 401 }
      )
    }

    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        plan: user.plan,
        credits: user.credits,
      },
    })
  } catch (error: any) {
    console.error('Auth error:', error)
    return NextResponse.json(
      { error: 'حدث خطأ في الخادم' },
      { status: 500 }
    )
  }
}
