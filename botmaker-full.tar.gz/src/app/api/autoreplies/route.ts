import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Get user from session
async function getUser(request: NextRequest) {
  const authHeader = request.headers.get('authorization')
  const token = authHeader?.replace('Bearer ', '')
  
  if (!token) return null

  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  })

  if (!session || session.expiresAt < new Date()) {
    return null
  }

  return session.user
}

// GET - Get auto replies
export async function GET(request: NextRequest) {
  try {
    const user = await getUser(request)
    if (!user) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const botId = searchParams.get('botId')

    if (!botId) {
      return NextResponse.json({ error: 'معرف البوت مطلوب' }, { status: 400 })
    }

    const bot = await db.bot.findFirst({
      where: { id: botId, userId: user.id },
    })

    if (!bot) {
      return NextResponse.json({ error: 'البوت غير موجود' }, { status: 404 })
    }

    const autoReplies = await db.autoReply.findMany({
      where: { botId },
      orderBy: [{ priority: 'desc' }, { createdAt: 'desc' }],
    })

    return NextResponse.json({ autoReplies })
  } catch (error: any) {
    console.error('Get auto replies error:', error)
    return NextResponse.json({ error: 'حدث خطأ في الخادم' }, { status: 500 })
  }
}

// POST - Create auto reply
export async function POST(request: NextRequest) {
  try {
    const user = await getUser(request)
    if (!user) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
    }

    const body = await request.json()
    const { botId, keyword, matchType, response, responseType, mediaUrl, isActive, priority } = body

    if (!botId || !keyword || !response) {
      return NextResponse.json({ error: 'جميع الحقول مطلوبة' }, { status: 400 })
    }

    const bot = await db.bot.findFirst({
      where: { id: botId, userId: user.id },
    })

    if (!bot) {
      return NextResponse.json({ error: 'البوت غير موجود' }, { status: 404 })
    }

    const autoReply = await db.autoReply.create({
      data: {
        botId,
        keyword,
        matchType: matchType || 'contains',
        response,
        responseType: responseType || 'text',
        mediaUrl,
        isActive: isActive ?? true,
        priority: priority || 0,
      },
    })

    return NextResponse.json({ success: true, autoReply })
  } catch (error: any) {
    console.error('Create auto reply error:', error)
    return NextResponse.json({ error: 'حدث خطأ في الخادم' }, { status: 500 })
  }
}

// PUT - Update auto reply
export async function PUT(request: NextRequest) {
  try {
    const user = await getUser(request)
    if (!user) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
    }

    const body = await request.json()
    const { id, keyword, matchType, response, responseType, mediaUrl, isActive, priority } = body

    if (!id) {
      return NextResponse.json({ error: 'معرف الرد مطلوب' }, { status: 400 })
    }

    const existing = await db.autoReply.findUnique({
      where: { id },
      include: { bot: true },
    })

    if (!existing || existing.bot.userId !== user.id) {
      return NextResponse.json({ error: 'الرد غير موجود' }, { status: 404 })
    }

    const updated = await db.autoReply.update({
      where: { id },
      data: { keyword, matchType, response, responseType, mediaUrl, isActive, priority },
    })

    return NextResponse.json({ success: true, autoReply: updated })
  } catch (error: any) {
    console.error('Update auto reply error:', error)
    return NextResponse.json({ error: 'حدث خطأ في الخادم' }, { status: 500 })
  }
}

// DELETE - Delete auto reply
export async function DELETE(request: NextRequest) {
  try {
    const user = await getUser(request)
    if (!user) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'معرف الرد مطلوب' }, { status: 400 })
    }

    const autoReply = await db.autoReply.findUnique({
      where: { id },
      include: { bot: true },
    })

    if (!autoReply || autoReply.bot.userId !== user.id) {
      return NextResponse.json({ error: 'الرد غير موجود' }, { status: 404 })
    }

    await db.autoReply.delete({ where: { id } })

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('Delete auto reply error:', error)
    return NextResponse.json({ error: 'حدث خطأ في الخادم' }, { status: 500 })
  }
}
