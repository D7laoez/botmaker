import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { TelegramBotAPI, TelegramUpdate } from '@/lib/telegram'

// POST /api/webhook/[botId] - Handle Telegram webhook
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ botId: string }> }
) {
  try {
    const { botId } = await params
    
    // Verify bot exists and is active
    const bot = await db.bot.findUnique({
      where: { id: botId },
      include: {
        commands: { where: { isActive: true } },
        autoReplies: { where: { isActive: true }, orderBy: { priority: 'desc' } },
      },
    })

    if (!bot || !bot.isActive) {
      return NextResponse.json({ error: 'Bot not found or inactive' }, { status: 404 })
    }

    // Parse update from Telegram
    const update: TelegramUpdate = await request.json()
    
    console.log(`Webhook received for bot ${bot.name}:`, update.update_id)

    // Create Telegram API instance
    const telegram = new TelegramBotAPI(bot.token)

    // Process the update
    try {
      // Handle messages
      if (update.message) {
        const { message } = update
        const chatId = message.chat.id

        // Save message to database
        await db.message.create({
          data: {
            botId,
            telegramId: String(message.message_id),
            direction: 'incoming',
            type: message.text ? 'text' : (message.photo ? 'photo' : (message.video ? 'video' : 'other')),
            content: message.text || message.caption,
          },
        })

        // Update message count
        await db.bot.update({
          where: { id: botId },
          data: { messagesCount: { increment: 1 } },
        })

        // Track subscriber (only for private chats)
        if (message.from && message.chat.type === 'private') {
          await db.subscriber.upsert({
            where: {
              botId_telegramId: {
                botId,
                telegramId: String(message.from.id),
              },
            },
            create: {
              botId,
              telegramId: String(message.from.id),
              username: message.from.username,
              firstName: message.from.first_name,
              lastName: message.from.last_name,
              languageCode: message.from.language_code,
            },
            update: {
              username: message.from.username,
              firstName: message.from.first_name,
              lastName: message.from.last_name,
              lastActiveAt: new Date(),
            },
          })

          // Update subscriber count
          const count = await db.subscriber.count({ where: { botId } })
          await db.bot.update({
            where: { id: botId },
            data: { subscribersCount: count },
          })
        }

        // Handle commands
        if (message.text?.startsWith('/')) {
          const parts = message.text.slice(1).split(' ')
          const command = parts[0].toLowerCase().split('@')[0] // Remove bot username if present
          
          const botCommand = bot.commands.find(c => c.command.toLowerCase() === command)

          if (botCommand) {
            await telegram.sendMessage(chatId, botCommand.response, {
              parse_mode: 'HTML',
            })
            return NextResponse.json({ ok: true, handled: 'command' })
          }

          // Default commands
          switch (command) {
            case 'start':
              await telegram.sendMessage(chatId, bot.welcomeMessage || 'مرحباً بك! كيف يمكنني مساعدتك؟', {
                parse_mode: 'HTML',
              })
              return NextResponse.json({ ok: true, handled: 'start' })
            
            case 'help':
              const helpText = bot.commands.length > 0
                ? '📋 الأوامر المتاحة:\n\n' + bot.commands.map(c => `/${c.command} - ${c.description || 'لا يوجد وصف'}`).join('\n')
                : 'لا توجد أوامر مخصصة. استخدم /start للبدء.'
              await telegram.sendMessage(chatId, helpText, { parse_mode: 'HTML' })
              return NextResponse.json({ ok: true, handled: 'help' })
          }
          
          return NextResponse.json({ ok: true, handled: 'unknown_command' })
        }

        // Handle auto replies
        if (message.text) {
          const text = message.text.toLowerCase()
          
          for (const autoReply of bot.autoReplies) {
            let match = false
            const keyword = autoReply.keyword.toLowerCase()

            switch (autoReply.matchType) {
              case 'exact':
                match = text === keyword
                break
              case 'contains':
                match = text.includes(keyword)
                break
              case 'starts_with':
                match = text.startsWith(keyword)
                break
              case 'regex':
                try {
                  const regex = new RegExp(autoReply.keyword, 'i')
                  match = regex.test(message.text)
                } catch (e) {
                  // Invalid regex, skip
                }
                break
            }

            if (match) {
              await telegram.sendMessage(chatId, autoReply.response, {
                parse_mode: 'HTML',
              })
              return NextResponse.json({ ok: true, handled: 'auto_reply' })
            }
          }
        }

        return NextResponse.json({ ok: true, handled: 'none' })
      }

      // Handle callback queries
      if (update.callback_query) {
        const { callback_query } = update
        await telegram.answerCallbackQuery(callback_query.id)
        
        if (callback_query.data && callback_query.message) {
          console.log('Callback data:', callback_query.data)
        }
        
        return NextResponse.json({ ok: true, handled: 'callback' })
      }

      // Handle channel posts
      if (update.channel_post) {
        console.log('Channel post:', update.channel_post)
        return NextResponse.json({ ok: true, handled: 'channel_post' })
      }

      // Handle my_chat_member updates
      if (update.my_chat_member) {
        const { my_chat_member } = update
        const chatId = my_chat_member.chat.id
        const status = my_chat_member.new_chat_member.status
        
        if (status === 'administrator' || status === 'member') {
          await db.channel.upsert({
            where: {
              botId_channelId: {
                botId,
                channelId: String(chatId),
              },
            },
            create: {
              botId,
              channelId: String(chatId),
              title: my_chat_member.chat.title || 'Private Chat',
              username: my_chat_member.chat.username,
              type: my_chat_member.chat.type,
            },
            update: {
              title: my_chat_member.chat.title || 'Private Chat',
              username: my_chat_member.chat.username,
              isActive: true,
            },
          })
        } else if (status === 'left' || status === 'kicked') {
          await db.channel.updateMany({
            where: { botId, channelId: String(chatId) },
            data: { isActive: false },
          })
        }
        
        return NextResponse.json({ ok: true, handled: 'chat_member' })
      }

      return NextResponse.json({ ok: true, handled: 'unknown' })
    } catch (processError: any) {
      console.error('Error processing update:', processError)
      return NextResponse.json({ ok: true, error: processError.message })
    }
  } catch (error: any) {
    console.error('Webhook error:', error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

// GET - Verify webhook
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ botId: string }> }
) {
  const { botId } = await params
  return NextResponse.json({ status: 'active', botId })
}
