import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { TelegramBotAPI } from '@/lib/telegram'

// Get user from session
async function getUser(request: NextRequest) {
  const authHeader = request.headers.get('authorization')
  const token = authHeader?.replace('Bearer ', '')
  
  if (!token) return null

  const session = await db.session.findUnique({
    where: { token },
    include: { user: true },
  })

  if (!session || session.expiresAt < new Date()) {
    return null
  }

  return session.user
}

// GET - Get channels
export async function GET(request: NextRequest) {
  try {
    const user = await getUser(request)
    if (!user) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const botId = searchParams.get('botId')

    if (!botId) {
      return NextResponse.json({ error: 'معرف البوت مطلوب' }, { status: 400 })
    }

    const bot = await db.bot.findFirst({
      where: { id: botId, userId: user.id },
    })

    if (!bot) {
      return NextResponse.json({ error: 'البوت غير موجود' }, { status: 404 })
    }

    const channels = await db.channel.findMany({
      where: { botId },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ channels })
  } catch (error: any) {
    console.error('Get channels error:', error)
    return NextResponse.json({ error: 'حدث خطأ في الخادم' }, { status: 500 })
  }
}

// POST - Sync channels (get fresh info from Telegram)
export async function POST(request: NextRequest) {
  try {
    const user = await getUser(request)
    if (!user) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
    }

    const body = await request.json()
    const { botId, action, channelId, message } = body

    const bot = await db.bot.findFirst({
      where: { id: botId, userId: user.id },
    })

    if (!bot) {
      return NextResponse.json({ error: 'البوت غير موجود' }, { status: 404 })
    }

    const telegram = new TelegramBotAPI(bot.token)

    // Send message to channel
    if (action === 'sendMessage' && channelId && message) {
      const result = await telegram.sendMessage(channelId, message, {
        parse_mode: 'HTML',
      })

      return NextResponse.json({ success: true, messageId: result.message_id })
    }

    // Get channel info
    if (action === 'getInfo' && channelId) {
      const chatInfo = await telegram.getChat(channelId)
      const memberCount = await telegram.getChatMemberCount(channelId)

      return NextResponse.json({ 
        success: true, 
        channel: {
          id: chatInfo.id,
          title: chatInfo.title,
          username: chatInfo.username,
          type: chatInfo.type,
          memberCount,
        }
      })
    }

    // Leave channel
    if (action === 'leave' && channelId) {
      await telegram.leaveChat(channelId)
      
      await db.channel.updateMany({
        where: { botId, channelId: String(channelId) },
        data: { isActive: false },
      })

      return NextResponse.json({ success: true })
    }

    return NextResponse.json({ error: 'إجراء غير معروف' }, { status: 400 })
  } catch (error: any) {
    console.error('Channel action error:', error)
    return NextResponse.json({ error: error.message || 'حدث خطأ في الخادم' }, { status: 500 })
  }
}

// DELETE - Remove channel
export async function DELETE(request: NextRequest) {
  try {
    const user = await getUser(request)
    if (!user) {
      return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')
    const botId = searchParams.get('botId')

    if (!id || !botId) {
      return NextResponse.json({ error: 'المعرفات مطلوبة' }, { status: 400 })
    }

    const channel = await db.channel.findFirst({
      where: { id, botId },
      include: { bot: true },
    })

    if (!channel || channel.bot.userId !== user.id) {
      return NextResponse.json({ error: 'القناة غير موجودة' }, { status: 404 })
    }

    // Leave the channel
    try {
      const telegram = new TelegramBotAPI(channel.bot.token)
      await telegram.leaveChat(channel.channelId)
    } catch (e) {
      console.error('Error leaving channel:', e)
    }

    await db.channel.delete({ where: { id } })

    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('Delete channel error:', error)
    return NextResponse.json({ error: 'حدث خطأ في الخادم' }, { status: 500 })
  }
}
