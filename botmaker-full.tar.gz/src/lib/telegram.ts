/**
 * Telegram Bot API Service
 * Handles all interactions with Telegram Bot API
 */

export interface TelegramUser {
  id: number
  is_bot: boolean
  first_name: string
  last_name?: string
  username?: string
  language_code?: string
}

export interface TelegramChat {
  id: number
  type: 'private' | 'group' | 'supergroup' | 'channel'
  title?: string
  username?: string
  first_name?: string
  last_name?: string
}

export interface TelegramMessage {
  message_id: number
  from?: TelegramUser
  chat: TelegramChat
  date: number
  text?: string
  caption?: string
  photo?: Array<{ file_id: string; file_size: number; width: number; height: number }>
  video?: { file_id: string; file_size: number; width: number; height: number }
  document?: { file_id: string; file_name?: string; mime_type?: string }
  contact?: { phone_number: string; first_name: string; last_name?: string }
  location?: { latitude: number; longitude: number }
}

export interface TelegramUpdate {
  update_id: number
  message?: TelegramMessage
  edited_message?: TelegramMessage
  channel_post?: TelegramMessage
  edited_channel_post?: TelegramMessage
  callback_query?: {
    id: string
    from: TelegramUser
    message?: TelegramMessage
    data?: string
  }
  my_chat_member?: {
    chat: TelegramChat
    from: TelegramUser
    date: number
    old_chat_member: any
    new_chat_member: any
  }
}

export interface TelegramBotInfo {
  id: number
  is_bot: true
  first_name: string
  username: string
  can_join_groups: boolean
  can_read_all_group_messages: boolean
  supports_inline_queries: boolean
}

export interface InlineKeyboardButton {
  text: string
  url?: string
  callback_data?: string
  switch_inline_query?: string
}

export interface InlineKeyboardMarkup {
  inline_keyboard: InlineKeyboardButton[][]
}

export class TelegramBotAPI {
  private token: string
  private baseUrl: string

  constructor(token: string) {
    this.token = token
    this.baseUrl = `https://api.telegram.org/bot${token}`
  }

  /**
   * Make API request to Telegram
   */
  private async request<T>(method: string, params?: Record<string, any>): Promise<T> {
    const url = `${this.baseUrl}/${method}`
    
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: params ? JSON.stringify(params) : undefined,
      })

      const data = await response.json()

      if (!data.ok) {
        throw new Error(`Telegram API Error: ${data.description || 'Unknown error'}`)
      }

      return data.result
    } catch (error: any) {
      console.error(`Telegram API request failed (${method}):`, error.message)
      throw error
    }
  }

  /**
   * Get bot information
   */
  async getMe(): Promise<TelegramBotInfo> {
    return this.request<TelegramBotInfo>('getMe')
  }

  /**
   * Validate bot token by calling getMe
   */
  async validateToken(): Promise<{ valid: boolean; botInfo?: TelegramBotInfo; error?: string }> {
    try {
      const botInfo = await this.getMe()
      return { valid: true, botInfo }
    } catch (error: any) {
      return { valid: false, error: error.message }
    }
  }

  /**
   * Set webhook for the bot
   */
  async setWebhook(webhookUrl: string): Promise<boolean> {
    return this.request<boolean>('setWebhook', { url: webhookUrl })
  }

  /**
   * Delete webhook
   */
  async deleteWebhook(): Promise<boolean> {
    return this.request<boolean>('deleteWebhook')
  }

  /**
   * Get webhook info
   */
  async getWebhookInfo(): Promise<any> {
    return this.request('getWebhookInfo')
  }

  /**
   * Send text message
   */
  async sendMessage(
    chatId: number | string,
    text: string,
    options?: {
      parse_mode?: 'HTML' | 'Markdown' | 'MarkdownV2'
      disable_web_page_preview?: boolean
      disable_notification?: boolean
      reply_to_message_id?: number
      reply_markup?: InlineKeyboardMarkup
    }
  ): Promise<TelegramMessage> {
    return this.request<TelegramMessage>('sendMessage', {
      chat_id: chatId,
      text,
      ...options,
    })
  }

  /**
   * Send photo
   */
  async sendPhoto(
    chatId: number | string,
    photo: string, // file_id or URL
    caption?: string,
    options?: {
      parse_mode?: 'HTML' | 'Markdown' | 'MarkdownV2'
      disable_notification?: boolean
      reply_markup?: InlineKeyboardMarkup
    }
  ): Promise<TelegramMessage> {
    return this.request<TelegramMessage>('sendPhoto', {
      chat_id: chatId,
      photo,
      caption,
      ...options,
    })
  }

  /**
   * Send document
   */
  async sendDocument(
    chatId: number | string,
    document: string,
    caption?: string,
    options?: {
      parse_mode?: 'HTML' | 'Markdown' | 'MarkdownV2'
      disable_notification?: boolean
      reply_markup?: InlineKeyboardMarkup
    }
  ): Promise<TelegramMessage> {
    return this.request<TelegramMessage>('sendDocument', {
      chat_id: chatId,
      document,
      caption,
      ...options,
    })
  }

  /**
   * Send video
   */
  async sendVideo(
    chatId: number | string,
    video: string,
    caption?: string,
    options?: {
      parse_mode?: 'HTML' | 'Markdown' | 'MarkdownV2'
      disable_notification?: boolean
      reply_markup?: InlineKeyboardMarkup
    }
  ): Promise<TelegramMessage> {
    return this.request<TelegramMessage>('sendVideo', {
      chat_id: chatId,
      video,
      caption,
      ...options,
    })
  }

  /**
   * Send chat action (typing, upload_photo, etc.)
   */
  async sendChatAction(
    chatId: number | string,
    action: 'typing' | 'upload_photo' | 'record_video' | 'upload_video' | 'record_voice' | 'upload_voice' | 'upload_document' | 'find_location'
  ): Promise<boolean> {
    return this.request<boolean>('sendChatAction', {
      chat_id: chatId,
      action,
    })
  }

  /**
   * Get chat information
   */
  async getChat(chatId: number | string): Promise<TelegramChat> {
    return this.request<TelegramChat>('getChat', { chat_id: chatId })
  }

  /**
   * Get chat member count
   */
  async getChatMemberCount(chatId: number | string): Promise<number> {
    return this.request<number>('getChatMemberCount', { chat_id: chatId })
  }

  /**
   * Get chat member info
   */
  async getChatMember(chatId: number | string, userId: number): Promise<any> {
    return this.request('getChatMember', {
      chat_id: chatId,
      user_id: userId,
    })
  }

  /**
   * Leave chat
   */
  async leaveChat(chatId: number | string): Promise<boolean> {
    return this.request<boolean>('leaveChat', { chat_id: chatId })
  }

  /**
   * Answer callback query
   */
  async answerCallbackQuery(
    callbackQueryId: string,
    text?: string,
    showAlert?: boolean
  ): Promise<boolean> {
    return this.request<boolean>('answerCallbackQuery', {
      callback_query_id: callbackQueryId,
      text,
      show_alert: showAlert,
    })
  }

  /**
   * Edit message text
   */
  async editMessageText(
    chatId: number | string,
    messageId: number,
    text: string,
    options?: {
      parse_mode?: 'HTML' | 'Markdown' | 'MarkdownV2'
      disable_web_page_preview?: boolean
      reply_markup?: InlineKeyboardMarkup
    }
  ): Promise<TelegramMessage | boolean> {
    return this.request('editMessageText', {
      chat_id: chatId,
      message_id: messageId,
      text,
      ...options,
    })
  }

  /**
   * Delete message
   */
  async deleteMessage(chatId: number | string, messageId: number): Promise<boolean> {
    return this.request<boolean>('deleteMessage', {
      chat_id: chatId,
      message_id: messageId,
    })
  }

  /**
   * Forward message
   */
  async forwardMessage(
    chatId: number | string,
    fromChatId: number | string,
    messageId: number,
    disableNotification?: boolean
  ): Promise<TelegramMessage> {
    return this.request<TelegramMessage>('forwardMessage', {
      chat_id: chatId,
      from_chat_id: fromChatId,
      message_id: messageId,
      disable_notification: disableNotification,
    })
  }

  /**
   * Copy message
   */
  async copyMessage(
    chatId: number | string,
    fromChatId: number | string,
    messageId: number,
    caption?: string,
    options?: {
      parse_mode?: 'HTML' | 'Markdown' | 'MarkdownV2'
      disable_notification?: boolean
      reply_markup?: InlineKeyboardMarkup
    }
  ): Promise<{ message_id: number }> {
    return this.request('copyMessage', {
      chat_id: chatId,
      from_chat_id: fromChatId,
      message_id: messageId,
      caption,
      ...options,
    })
  }

  /**
   * Send poll
   */
  async sendPoll(
    chatId: number | string,
    question: string,
    options: string[],
    params?: {
      is_anonymous?: boolean
      type?: 'regular' | 'quiz'
      allows_multiple_answers?: boolean
      correct_option_id?: number
    }
  ): Promise<TelegramMessage> {
    return this.request<TelegramMessage>('sendPoll', {
      chat_id: chatId,
      question,
      options: JSON.stringify(options),
      ...params,
    })
  }

  /**
   * Send contact
   */
  async sendContact(
    chatId: number | string,
    phoneNumber: string,
    firstName: string,
    lastName?: string
  ): Promise<TelegramMessage> {
    return this.request<TelegramMessage>('sendContact', {
      chat_id: chatId,
      phone_number: phoneNumber,
      first_name: firstName,
      last_name: lastName,
    })
  }

  /**
   * Send location
   */
  async sendLocation(
    chatId: number | string,
    latitude: number,
    longitude: number,
    title?: string,
    address?: string
  ): Promise<TelegramMessage> {
    return this.request<TelegramMessage>('sendLocation', {
      chat_id: chatId,
      latitude,
      longitude,
    })
  }

  /**
   * Set bot commands
   */
  async setMyCommands(commands: Array<{ command: string; description: string }>): Promise<boolean> {
    return this.request<boolean>('setMyCommands', {
      commands: JSON.stringify(commands),
    })
  }

  /**
   * Get bot commands
   */
  async getMyCommands(): Promise<Array<{ command: string; description: string }>> {
    return this.request('getMyCommands')
  }

  /**
   * Delete bot commands
   */
  async deleteMyCommands(): Promise<boolean> {
    return this.request<boolean>('deleteMyCommands')
  }

  /**
   * Set bot description
   */
  async setMyDescription(description: string): Promise<boolean> {
    return this.request<boolean>('setMyDescription', { description })
  }

  /**
   * Set bot short description
   */
  async setMyShortDescription(shortDescription: string): Promise<boolean> {
    return this.request<boolean>('setMyShortDescription', { short_description: shortDescription })
  }

  /**
   * Get file URL
   */
  getFileUrl(fileId: string): string {
    return `https://api.telegram.org/file/bot${this.token}/${fileId}`
  }

  /**
   * Get file info
   */
  async getFile(fileId: string): Promise<{ file_id: string; file_unique_id: string; file_size?: number; file_path?: string }> {
    return this.request('getFile', { file_id: fileId })
  }

  /**
   * Create inline keyboard markup
   */
  static createInlineKeyboard(buttons: InlineKeyboardButton[][]): InlineKeyboardMarkup {
    return { inline_keyboard: buttons }
  }

  /**
   * Create inline button
   */
  static createInlineButton(text: string, options?: { url?: string; callback_data?: string }): InlineKeyboardButton {
    return { text, ...options }
  }
}

/**
 * Process incoming update from Telegram webhook
 */
export async function processTelegramUpdate(botId: string, update: TelegramUpdate, db: any): Promise<void> {
  const bot = await db.bot.findUnique({
    where: { id: botId },
    include: {
      commands: true,
      autoReplies: true,
    },
  })

  if (!bot || !bot.isActive) {
    return
  }

  const telegram = new TelegramBotAPI(bot.token)

  // Handle regular messages
  if (update.message) {
    const { message } = update
    const chatId = message.chat.id

    // Save message to database
    await db.message.create({
      data: {
        botId,
        telegramId: String(message.message_id),
        direction: 'incoming',
        type: message.text ? 'text' : (message.photo ? 'photo' : (message.video ? 'video' : 'other')),
        content: message.text || message.caption,
      },
    })

    // Track subscriber
    if (message.from && message.chat.type === 'private') {
      await db.subscriber.upsert({
        where: {
          botId_telegramId: {
            botId,
            telegramId: String(message.from.id),
          },
        },
        create: {
          botId,
          telegramId: String(message.from.id),
          username: message.from.username,
          firstName: message.from.first_name,
          lastName: message.from.last_name,
          languageCode: message.from.language_code,
        },
        update: {
          username: message.from.username,
          firstName: message.from.first_name,
          lastName: message.from.last_name,
          lastActiveAt: new Date(),
        },
      })
    }

    // Handle commands
    if (message.text?.startsWith('/')) {
      const [command, ...args] = message.text.slice(1).split(' ')
      const botCommand = bot.commands.find(c => c.command.toLowerCase() === command.toLowerCase())

      if (botCommand && botCommand.isActive) {
        await telegram.sendMessage(chatId, botCommand.response, {
          parse_mode: 'HTML',
        })
        return
      }

      // Default command handling
      switch (command.toLowerCase()) {
        case 'start':
          const welcomeMsg = bot.welcomeMessage || 'مرحباً بك! كيف يمكنني مساعدتك؟'
          await telegram.sendMessage(chatId, welcomeMsg, { parse_mode: 'HTML' })
          break
        case 'help':
          const helpText = bot.commands
            .filter(c => c.isActive)
            .map(c => `/${c.command} - ${c.description || c.response.slice(0, 50)}`)
            .join('\n')
          await telegram.sendMessage(chatId, helpText || 'لا توجد أوامر متاحة', { parse_mode: 'HTML' })
          break
      }
      return
    }

    // Handle auto replies
    if (message.text) {
      for (const autoReply of bot.autoReplies.filter(r => r.isActive)) {
        let match = false
        const text = message.text.toLowerCase()
        const keyword = autoReply.keyword.toLowerCase()

        switch (autoReply.matchType) {
          case 'exact':
            match = text === keyword
            break
          case 'contains':
            match = text.includes(keyword)
            break
          case 'starts_with':
            match = text.startsWith(keyword)
            break
          case 'regex':
            try {
              const regex = new RegExp(autoReply.keyword, 'i')
              match = regex.test(message.text)
            } catch (e) {
              // Invalid regex, skip
            }
            break
        }

        if (match) {
          await telegram.sendMessage(chatId, autoReply.response, { parse_mode: 'HTML' })
          return
        }
      }
    }
  }

  // Handle channel posts
  if (update.channel_post) {
    // Log channel post
    console.log('Channel post received:', update.channel_post)
  }

  // Handle callback queries (inline button clicks)
  if (update.callback_query) {
    const { callback_query } = update
    await telegram.answerCallbackQuery(callback_query.id, 'تم!')
    
    // Handle callback data
    if (callback_query.data) {
      // Process callback data
      console.log('Callback data:', callback_query.data)
    }
  }

  // Handle chat member updates (bot added to/removed from chat)
  if (update.my_chat_member) {
    const { my_chat_member } = update
    const chatId = my_chat_member.chat.id
    
    if (my_chat_member.new_chat_member.status === 'administrator' || 
        my_chat_member.new_chat_member.status === 'member') {
      // Bot was added to chat/channel
      await db.channel.upsert({
        where: {
          botId_channelId: {
            botId,
            channelId: String(chatId),
          },
        },
        create: {
          botId,
          channelId: String(chatId),
          title: my_chat_member.chat.title || 'Private Chat',
          username: my_chat_member.chat.username,
          type: my_chat_member.chat.type,
        },
        update: {
          title: my_chat_member.chat.title || 'Private Chat',
          username: my_chat_member.chat.username,
          isActive: true,
        },
      })
    } else if (my_chat_member.new_chat_member.status === 'left' || 
               my_chat_member.new_chat_member.status === 'kicked') {
      // Bot was removed from chat/channel
      await db.channel.updateMany({
        where: {
          botId,
          channelId: String(chatId),
        },
        data: { isActive: false },
      })
    }
  }
}
